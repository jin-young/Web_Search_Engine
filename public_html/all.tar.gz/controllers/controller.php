<?php
	include_once("../models/dbModel.php");

	$company = $_GET["company"];
	$title = $_GET["title"];
	$url = $_GET["url"];
	$content = $_GET["content"];
	$cost = $_GET["cost"];
	switch($reguest){
		case "register":
			register($company, $title, $url, $content, $cost);
			break;
	}

?>
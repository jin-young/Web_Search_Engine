<?php

	function register($company, $title, $url, $content, $cost){
		$db_type = "mysql";
		$db_server = "";
		$db_name = "";
		$db_user = "";
		$db_password = "";

		$db_conn = mysql_connect($db_server, $db_user, $db_password);
		$db_selected = mysql_select_db($db_name, $db_conn);
		$query = "INSERT INTO object
			  VALUES ('".$company."', '".$title."', '".$url."', '".$content."', '".$cost."')";	
		mysql_query($query, $db_conn);
		mysql_close($db_conn);
	}

?>
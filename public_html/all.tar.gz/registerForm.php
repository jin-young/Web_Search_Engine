<script type="text/javascript"
	src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.0/jquery.validate.js"></script>
<style type="text/css">
.error {
	color: red;
}
</style>

<h2 style="padding-top: 0px; xsmargin-top: 0px;">Add New Advertisement</h2>
<br />
<form action="addadvertising.html" method="post" id="addqform"
		enctype="multipart/form-data">
	<table bgcolor="#FFF">
		<tr>
			<td> 
				<input type="text" id="company" value="Company" 
					onFocus="this.value=''" style="background-color:#dfffff;color:gray">
			</td>
		</tr>
		<tr>
			<td> 
				<input type="text" id="title" value="Title" 
					onFocus="this.value=''" style="background-color:#dfffff;color:gray">
			</td>
		</tr>
		<tr>
			<td> 
				<input type="text" id="url" value="URL" 
					onFocus="this.value=''" style="background-color:#dfffff;color:gray">
			</td>
		</tr>
		<tr>
			<td> 
				<textarea id="content" rows="10" cols="50" style="background-color:#dfffff;">
				</textarea>
			</td>
		</tr>
		<tr>
			<td> 
				$&nbsp;<input type="text" id="cost" value="Cost" 
					onFocus="this.value=''" style="background-color:#dfffff;color:gray">
			</td>
		</tr>
		<tr>
			<td align="center"> <!-- the argument should check -->
				<button type="button" onClick="register($('#company').attr('value'), 
														$('#title').attr('value'),
														$('#url').attr('value'),
														$('#content').attr('value'),
														$('#cost').attr('value'))">
				Register</button>
				&nbsp;&nbsp;&nbsp;&nbsp;
				<button type="button" onClick="clearAll();">Cancel</button>
			</td>
	</table>
</form>
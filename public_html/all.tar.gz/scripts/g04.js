$(document).ready(function(){
	$("#blurLayer").click(function(e){
		clearAll();		
	});
})

function clearAll(){
	$("#blurLayer").fadeOut();
	$("#registerForm").fadeOut();
}

function getInstance()
{	
	if(window.XMLHttpRequest) // For using IE7, Firefox, Chrome, Opera, Safari
	{
		xmlhttp = new XMLHttpRequest();
	} 
	else if (window.ActiveXObject) // For using IE6, IE5
	{
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	} 
	else	// This browser cannot use Ajax
		alert("I'm so sorry. Your browser cannot support the XMLHTTP");
	return xmlhttp;
}

function openRegForm(){
	xmlhttp = getInstance();
	xmlhttp.onreadystatechange=function(){
		if(xmlhttp.readyState == 4)
		{
			$("#blurLayer").attr("style", "display:block");
			$("#registerForm").html(xmlhttp.responseText);
			var left = $(window).width()/2 - $("#registerForm").width()/2;
			var top = $(window).height()/2 - $("#registerForm").height()/2;	
			$("#registerForm").attr("style", "display:block;left:"+left+"px;top:"+top+"px");
		}
	}
	var url = root_url + "registerForm.php";
	xmlhttp.open("GET", url, true);
	xmlhttp.send(null);
}

function register(company, title, url, content, cost){
	xmlhttp = getInstance();
	xmlhttp.onreadystatechange=function(){
		if(xmlhttp.readyState == 4)
		{
			clearAll();
			alert("Registered Your Advertisement<br>Thank You");
		}
	}
	var condition = "?request=register";
	condition += "&company=" + company;
	condition += "&title=" + title;
	condition += "&url=" + url;
	condition += "&cost=" + cost;
	var url = "controllers/controller.php" + condition;
	xmlhttp.open("GET", url, true);
	xmlhttp.send(null);	
}